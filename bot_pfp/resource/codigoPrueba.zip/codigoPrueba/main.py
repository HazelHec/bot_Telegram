# Prueba para obtener datos del excel
import pandas as pd
from ecuacion2 import SRK
from conexion import conect1
import decimal


def aux(a):
    # Lista cuyo sera el directorio
    encabezado = ('Número', 'Componente', 'Formula', 'Masa molar',
                  'Temperatura Critica', 'Presión Critica', 'Factor acéntrico')
    lista = []
    # Metodos para la conexion con la base de datos
    conexion = conect1()
    cursor = conexion.cursor()
    # Query de consulta
    query = f'''SELECT * FROM svk_datos 
    where if((select count(*) from svk_datos where componente = '{a}') > 0,
    componente = '{a}', componente like ' % {a} % ');'''
    # Metodo para hacer consultas
    cursor.execute(query)
    data = cursor.fetchall()
    # print(data)
    if (len(data) == 0):
        # Devuelve un mesaje al usuario para que pueda volver a insertar el elemento
        print("""El elemento solicitado no se encuentra en la base de datos\n
              Intente de nuevo""")
        return None
    else:
        # Metodo por el cual obtenemos los datos en orden
        for dt in data:
            for d in dt:
                if (isinstance(d, decimal.Decimal)):
                    lista.append(float(d))
                else:
                    print(d)
                    lista.append(d)
            break
        datos = {encabezado: lista for encabezado,
                 lista in zip(encabezado, lista)}
        return datos
    conexion.commit()
    cursor.close()
    conexion.close()

    # print(data)


def elementos(numeroDeElementos, mmh7p=0, fah7p=0, yh7p=0, tch7p=0, pch7p=0):
    # Variables
    lista = []
    y = []
    con = 0
    # Creación de la info del heptano plus, si es que se solicita
    h7p = {
        "Número": '7+',
        "Componente": 'Heptano Plus',
        "Formula": 'H7+',
        "Masa molar": mmh7p,
        "Temperatura Critica": tch7p,
        "Presión Critica": pch7p,
        "Factor acéntrico": fah7p
    }

    while (con < numeroDeElementos):
        idElemento = input(f"Escribe el nombre del elemento {con+1}: \n")
        # Prueba de datos
        # Agregar condiciones para error humano como
        porcentaje = float(
            input(f"Escribe el porcentaje del elemento: {con+1} \n"))
        if (aux(idElemento) is not None):
            lista.append(aux(idElemento))  # Cambio para prueba
            aux(idElemento)
            y.append(porcentaje)
            con += 1

    if (mmh7p != 0):
        lista.append(h7p)
        y.append(yh7p)
        return lista, y
    else:
        return lista, y


def getDatos(lista, y):
    # Datos del usuario
    numeroDeElementos = int(input("Cuantos elementos necesistas:\n"))
    h7p = input("¿Uno de los elementos es h7+?\n")

    # Metodo por si se debe agregar h7
    if (h7p.lower() == "si"):
        # Masa molar, porcentaje y factor acentrico del h7+
        mmh7p = float(input("Ingresa la masa molar del h7+:\n"))
        tch7p = float(
            input("Ingresa la temperatura critica del h7+ en Farenheit:\n"))
        pch7p = float(input("Ingresa la presión critica del h7+:\n"))
        fah7p = float(input("Ingresa el factor acéntrico h7+:\n"))
        yh7p = float(input("Ingresa el porcentaje del h7+:\n"))
        lista, y = elementos(numeroDeElementos-1, mmh7p,
                             fah7p, yh7p, tch7p, pch7p)
    else:
        lista, y = elementos(numeroDeElementos)
    return numeroDeElementos, lista, y


def run():
    # Variables
    lista = []
    y = []

    # Decidir que tipo de problema es
    calcular = input("¿Qué deseas calcular?\nPresión o Densidad:\n")
    

    # Realizar problema de presión
    if (calcular.lower() == "presión" or calcular.lower() == "presion"):

        numeroDeElementos, lista, y = getDatos(lista, y)
        # Datos del problema en especifico
        temperatura = float(input("Escribe la temperatura en Rankine\n"))
        volumenCelda = float(input("Escribe el volumen de la celda en ft^3\n"))
        respuestaMC = input("¿Tiene el valor de mc?\n")
        if respuestaMC.lower() == 'si':
            mc = float(input("Introdusca el valor de mc\n"))
        # metodo para la solución
        SRK(lista, y, temperatura, numeroDeElementos, volumenCelda, mc)

    # Realizar problema de densidad
    elif (calcular == "densidad"):
        numeroDeElementos, lista, y = getDatos(lista, y)
        # Datos del problema en especifico
        presion = float(input("Escribe la presión en psia:\n"))
        temperatura = float(input("Escribe la temperatura en Rankine\n"))
        # metodo para la solución
        SRK(lista, y, temperatura, numeroDeElementos, P=presion)
    else:
        print("Tal acción no existe\n")
        run()


if __name__ == "__main__":
    run()
